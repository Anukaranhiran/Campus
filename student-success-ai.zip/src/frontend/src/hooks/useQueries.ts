import { useMutation, useQuery } from "@tanstack/react-query";
import type {
  AttendanceInput,
  AttendanceRisk,
  CareerSuggestion,
  StudentProfile,
} from "../backend.d";
import { useActor } from "./useActor";

export function useAddStudent() {
  const { actor } = useActor();
  return useMutation({
    mutationFn: async (profile: StudentProfile) => {
      if (!actor) throw new Error("Backend not ready");
      return actor.addStudent(profile);
    },
  });
}

export function useAddCareerSuggestion() {
  const { actor } = useActor();
  return useMutation({
    mutationFn: async ({
      studentId,
      suggestion,
    }: {
      studentId: string;
      suggestion: CareerSuggestion;
    }) => {
      if (!actor) throw new Error("Backend not ready");
      return actor.addCareerSuggestion(studentId, suggestion);
    },
  });
}

export function useCalculateAttendanceRisk() {
  const { actor } = useActor();
  return useMutation({
    mutationFn: async (input: AttendanceInput): Promise<AttendanceRisk> => {
      if (!actor) throw new Error("Backend not ready");
      return actor.calculateAttendanceRisk(input);
    },
  });
}

export function useGetAllStudents() {
  const { actor, isFetching } = useActor();
  return useQuery({
    queryKey: ["students"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllStudents();
    },
    enabled: !!actor && !isFetching,
  });
}

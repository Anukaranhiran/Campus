import type { CareerSuggestion } from "../backend.d";

// Smart suggestion generator based on branch + interests
export function generateSuggestions(
  branch: string,
  year: number,
  skills: string[],
  interests: string[],
): CareerSuggestion {
  const interestSet = new Set(interests.map((i) => i.toLowerCase()));
  const skillSet = new Set(skills.map((s) => s.toLowerCase()));

  // ── Skill Roadmaps ───────────────────────────────────────
  const roadmapMap: Record<string, string[]> = {
    "web dev": [
      "Master HTML5 semantics & CSS3 layouts (Flexbox, Grid)",
      "Deep-dive JavaScript — ES6+, async/await, DOM APIs",
      "Learn React 18 with hooks, state management & routing",
      "Build a full-stack project with Node.js + Express backend",
      "Deploy on Vercel/Netlify with CI/CD pipeline",
      "Contribute to open-source & build a polished portfolio",
    ],
    "ai/ml": [
      "Strengthen Python fundamentals — NumPy, Pandas, Matplotlib",
      "Study linear algebra & statistics for ML foundations",
      "Complete Andrew Ng's ML course on Coursera",
      "Build models with Scikit-learn, then TensorFlow / PyTorch",
      "Work on 2 end-to-end ML projects (classification + NLP)",
      "Deploy a model as a Flask / FastAPI REST API",
    ],
    cybersecurity: [
      "Learn networking fundamentals — TCP/IP, DNS, HTTP/S",
      "Study Linux command line & shell scripting",
      "Complete TryHackMe or HackTheBox beginner paths",
      "Learn OWASP Top 10 & web application security",
      "Practice CTF challenges weekly to sharpen skills",
      "Earn CompTIA Security+ or CEH certification",
    ],
    "data science": [
      "Master Python — Pandas, NumPy, Matplotlib & Seaborn",
      "Study statistics — distributions, hypothesis testing, regression",
      "Learn SQL for data wrangling and aggregation",
      "Build dashboards with Tableau or Power BI",
      "Complete an end-to-end EDA + ML pipeline project",
      "Publish analysis notebooks on Kaggle & GitHub",
    ],
    "app dev": [
      "Learn Flutter (Dart) or React Native for cross-platform apps",
      "Study mobile UX principles & Material Design guidelines",
      "Integrate REST APIs & local storage in mobile apps",
      "Publish a demo app to Play Store (developer account)",
      "Add Firebase auth + real-time database",
      "Optimize app performance & implement crash reporting",
    ],
    "game dev": [
      "Learn Unity basics — C#, scenes, physics, UI system",
      "Study game design fundamentals — loops, balance, progression",
      "Build 3 small games: endless runner, puzzle, platformer",
      "Implement player save systems & achievements",
      "Optimize for performance — batching, LOD, profiler",
      "Publish a game on itch.io and gather user feedback",
    ],
    cloud: [
      "Get AWS Cloud Practitioner certification (free prep available)",
      "Learn core services — EC2, S3, RDS, Lambda, IAM",
      "Study Docker & containerization fundamentals",
      "Learn Kubernetes for container orchestration",
      "Build a serverless app deployed on AWS Lambda",
      "Pursue AWS Solutions Architect Associate certification",
    ],
    devops: [
      "Master Linux administration & shell scripting",
      "Learn Git workflows — GitFlow, trunk-based development",
      "Study CI/CD pipelines with GitHub Actions or Jenkins",
      "Containerize apps with Docker & Docker Compose",
      "Learn Kubernetes for orchestration at scale",
      "Implement Infrastructure as Code with Terraform",
    ],
    robotics: [
      "Learn Python & C++ for embedded systems",
      "Study electronics basics — circuits, sensors, actuators",
      "Start with Arduino projects — line follower, obstacle avoidance",
      "Learn ROS (Robot Operating System) fundamentals",
      "Build a 3-DOF robotic arm with servo control",
      "Study PID controllers & path-planning algorithms",
    ],
  };

  // Detect primary interest
  const primaryInterest = interests.find((i) => roadmapMap[i.toLowerCase()]);
  const roadmapKey = primaryInterest?.toLowerCase() || "web dev";

  let skillRoadmap = roadmapMap[roadmapKey] || roadmapMap["web dev"];

  // Branch-specific overrides
  if (branch === "Mechanical" && interestSet.has("robotics")) {
    skillRoadmap = roadmapMap.robotics;
  } else if (branch === "Civil") {
    skillRoadmap = [
      "Master AutoCAD 2D — floor plans, structural drawings",
      "Learn STAAD.Pro for structural analysis & design",
      "Study REVIT BIM software for 3D building models",
      "Complete a real estate estimation project end-to-end",
      "Learn ETABS for high-rise building structural design",
      "Pursue CADD certification & build a project portfolio",
    ];
  } else if (branch === "Electronics") {
    skillRoadmap = [
      "Master circuit theory — KVL, KCL, op-amps, filters",
      "Learn PCB design with KiCad or Altium Designer",
      "Study embedded systems — STM32, ESP32, Raspberry Pi",
      "Work with sensors, ADCs & communication protocols (I2C, SPI, UART)",
      "Build an IoT project with MQTT + cloud dashboard",
      "Learn VLSI basics with Verilog/VHDL and simulation",
    ];
  }

  // ── Internship Domains ───────────────────────────────────
  const internshipMap: Record<string, string[]> = {
    "web dev": [
      "Full-Stack Web Development",
      "Frontend Engineering",
      "UI/UX Design",
      "Backend API Development",
    ],
    "ai/ml": [
      "Machine Learning Engineering",
      "Data Science & Analytics",
      "NLP Research",
      "Computer Vision",
    ],
    cybersecurity: [
      "Penetration Testing",
      "SOC Analyst",
      "Application Security",
      "Network Security",
    ],
    "data science": [
      "Data Analytics",
      "Business Intelligence",
      "Data Engineering",
      "ML Engineering",
    ],
    "app dev": [
      "Android/iOS Development",
      "React Native Development",
      "Mobile UI Engineering",
      "App Backend",
    ],
    "game dev": [
      "Unity Game Development",
      "Game Design",
      "AR/VR Development",
      "Game Testing",
    ],
    cloud: [
      "Cloud Solutions Architecture",
      "DevOps Engineering",
      "Site Reliability Engineering",
      "Cloud Security",
    ],
    devops: [
      "DevOps Engineering",
      "Platform Engineering",
      "SRE",
      "Cloud Infrastructure",
    ],
    robotics: [
      "Robotics Engineering",
      "Automation Engineering",
      "Embedded Systems",
      "IoT Development",
    ],
  };

  const internshipDomains =
    internshipMap[roadmapKey] || internshipMap["web dev"];

  // ── Project Ideas ────────────────────────────────────────
  const projectMap: Record<string, string[]> = {
    "web dev": [
      "AI-Powered Resume Analyzer — PDF upload + GPT feedback",
      "Real-Time Collaborative Whiteboard — WebSocket + Canvas",
      "Student Marketplace — Buy/sell textbooks with authentication",
      "Campus Event Tracker — Notifications + calendar integration",
      "Personal Finance Dashboard — Charts, goals & expense tracking",
    ],
    "ai/ml": [
      "Smart Attendance System — Face recognition with OpenCV",
      "Crop Disease Detector — CNN model + mobile interface",
      "AI Chatbot for College FAQs — RAG + LLM integration",
      "Student Performance Predictor — Regression model + dashboard",
      "Fake News Classifier — NLP + real-time article analysis",
    ],
    cybersecurity: [
      "Password Strength Analyzer — Entropy checker + breach database",
      "Network Port Scanner — Nmap wrapper with visual dashboard",
      "SQL Injection Detector — Static code analysis tool",
      "Phishing URL Detector — ML classifier + browser extension",
      "Log Anomaly Detection System — SIEM-lite with alerting",
    ],
    "data science": [
      "IPL Match Outcome Predictor — Historical data + ML model",
      "COVID Dashboard — Real-time data viz with Plotly",
      "Twitter Sentiment Analyzer — Live stream + NLP pipeline",
      "Stock Price Forecasting — LSTM + technical indicators",
      "E-commerce Recommendation Engine — Collaborative filtering",
    ],
    "app dev": [
      "Campus Lost & Found App — Image upload + push notifications",
      "Study Buddy Finder — Match students by subject + schedule",
      "Smart Expense Splitter — OCR receipt scanning + settlements",
      "Local Language Learning App — Flashcards + spaced repetition",
      "College Timetable Manager — AI schedule optimization",
    ],
    "game dev": [
      "2D Platformer with Procedural Levels — Unity + C#",
      "Multiplayer Quiz Battle — WebSocket-based real-time game",
      "AR Campus Navigation — ARCore + Unity",
      "Tower Defense with AI Enemies — Pathfinding + waves",
      "Puzzle Game with Level Editor — Save/share custom levels",
    ],
    cloud: [
      "Serverless Image Resizer — AWS Lambda + S3 + API Gateway",
      "Auto-Scaling Web App — ECS + Load Balancer + CloudFront",
      "Multi-Region Disaster Recovery — RTO/RPO documentation",
      "Kubernetes Microservices App — 3 services + Helm charts",
      "Cloud Cost Optimizer Dashboard — AWS Cost Explorer API",
    ],
    devops: [
      "Full CI/CD Pipeline — GitHub Actions + Docker + Kubernetes",
      "Infrastructure as Code — Terraform + AWS VPC + EC2",
      "Monitoring Stack — Prometheus + Grafana + alerting rules",
      "GitOps Deployment — ArgoCD + Helm + GitLab flow",
      "Log Aggregation Pipeline — ELK Stack + log parsing",
    ],
    robotics: [
      "Line Follower Robot — PID controller + IR sensors",
      "Smart Irrigation System — Soil moisture + weather API",
      "2-DOF Robotic Arm — Inverse kinematics + GUI control",
      "Obstacle Avoidance Bot — Ultrasonic + ESP32 + Bluetooth",
      "Gesture-Controlled Car — MPU6050 + NRF24L01 + Arduino",
    ],
  };

  const projectIdeas = projectMap[roadmapKey] || projectMap["web dev"];

  // ── Study Plan ───────────────────────────────────────────
  const studyPlanBase = [
    "Week 1: Foundation — Spend 2h/day on core concepts. Watch 1 tutorial series & take notes. Set up dev environment.",
    "Week 2: Build — Start your first mini-project from scratch. Focus on applying what you learned, not perfection.",
    "Week 3: Deepen — Add 1 advanced feature to your project. Read documentation, not just tutorials. Debug deliberately.",
    "Week 4: Polish & Present — Write a README, deploy the project, record a demo video. Share on LinkedIn & GitHub.",
  ];

  const yearAdjusted =
    year <= 1
      ? studyPlanBase
      : year === 2
        ? [
            "Week 1: Review fundamentals & fill skill gaps identified in previous semester",
            "Week 2: Build a medium complexity project (2-3 features, real API integration)",
            "Week 3: Study system design basics — databases, caching, authentication patterns",
            "Week 4: Prepare internship profile — resume, GitHub cleanup, 2-minute pitch",
          ]
        : [
            "Week 1: Deep-dive into a specialized advanced topic in your domain",
            "Week 2: Start a production-ready project with tests, CI/CD & documentation",
            "Week 3: Mock technical interviews — DSA + system design + domain questions",
            "Week 4: Apply to 10+ internships/placements & prep company-specific questions",
          ];

  // ── Resume Tips ──────────────────────────────────────────
  const resumeTips = [
    "Lead every bullet with a strong action verb (Built, Designed, Optimized, Automated, Deployed)",
    `Add quantifiable impact — "Reduced load time by 40%" beats "Improved performance"`,
    "List only your best 2-3 projects with live links — quality beats quantity every time",
    "Include your GitHub profile with a pinned README — recruiters DO check it",
    "Tailor your skills section to the JD; use exact keywords for ATS scoring",
    year >= 3
      ? "List any freelance work, open-source contributions, or competition wins prominently"
      : "Add coursework, certifications (even free ones), and hackathon participations",
  ];

  // If skills exist, add skill-specific tip
  if (skillSet.has("react") || skillSet.has("node.js")) {
    resumeTips[4] =
      "Highlight MERN/MEAN stack experience explicitly — very high demand in Indian job market";
  }

  return {
    skillRoadmap,
    internshipDomains,
    projectIdeas,
    studyPlan: yearAdjusted,
    resumeTips,
  };
}
